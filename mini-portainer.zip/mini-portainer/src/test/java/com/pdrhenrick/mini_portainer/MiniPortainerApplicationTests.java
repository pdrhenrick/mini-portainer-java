package com.pdrhenrick.mini_portainer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniPortainerApplicationTests {

	@Test
	void contextLoads() {
	}

}
