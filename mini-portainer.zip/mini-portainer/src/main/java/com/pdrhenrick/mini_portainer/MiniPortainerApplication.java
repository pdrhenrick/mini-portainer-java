package com.pdrhenrick.mini_portainer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniPortainerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniPortainerApplication.class, args);
	}

}
